import { MobileService } from './services/mobile.service';
import { AfterViewChecked, AfterViewInit, Component, OnChanges, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements AfterViewChecked, OnInit{
  constructor(private mobserv : MobileService){}
  title = 'electrosBridge';
  isLogin = false;
  // = this.mobserv.getLocal("userId") ? true : false

  ngOnInit(){
  }
  ngAfterViewChecked(){
    this.isLogin = this.mobserv.getLocal("userId") ? true : false
    console.log(this.isLogin)
  }
}
