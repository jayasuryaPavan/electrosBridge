import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProdTableComponent } from './prod-table/prod-table.component';



@NgModule({
  declarations: [
    ProdTableComponent
  ],
  imports: [
    CommonModule
  ],
  exports : [
    ProdTableComponent
  ]
})
export class SharedModule { }
