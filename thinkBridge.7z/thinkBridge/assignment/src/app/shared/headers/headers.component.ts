import { MobileService } from './../../services/mobile.service';
import { Component, Input, OnChanges, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2'
import { EventEmitter } from 'protractor';

@Component({
  selector: 'app-headers',
  templateUrl: './headers.component.html',
  styleUrls: ['./headers.component.css'],
})
export class HeadersComponent implements OnInit {
  constructor(private mobserv: MobileService, private router: Router) {}

  @Input() islogin
  // = this.mobserv.getLocal("userId") ? true : false
  ngOnInit(){
    this.mobserv.setSession('isedit', false);
    this.mobserv.mobile = {}
    this.islogin = this.mobserv.getLocal("userId") ? true : false
  }

  // ngOnChanges() {
  //   this.mobserv.setSession('isedit', false);
  //   this.islogin = this.mobserv.getLocal("userId") ? true : false
  // }

  back() {
    if(this.mobserv.getSession('thisPage') == 'false'){
    this.islogin = false
    Swal.fire({
      title: 'Logged out',
      text: 'Thank you for using bookstore',
      icon: 'success',
    }).then((result) => {
      if (result) {
        localStorage.clear();
        this.router.navigate(['/login']);
      }
    });
  }
  }
  prod(pro){
    if(this.islogin){
      if(pro == 'products'){
        this.router.navigateByUrl('/mobiles')
      }
      else if(pro == 'addProducts'){
        this.router.navigateByUrl('/Add')
      }
    }
    else{
      alert('Please login to redirect to View our Mobiles')
      this.router.navigateByUrl('/login')
    }
  }
}
