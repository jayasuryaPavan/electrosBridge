import { Component, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { EventEmitter } from 'selenium-webdriver';
import { AllapiService } from 'src/app/services/allapi.service';
import { MobileService } from 'src/app/services/mobile.service';

@Component({
  selector: 'app-prod-table',
  templateUrl: './prod-table.component.html',
  styleUrls: ['./prod-table.component.css']
})
export class ProdTableComponent implements OnInit {
  @Input() products: any = [];
  @Input() product
  @Input() brands : any = [];
  @Input() rams :any = [];
  @Input() prices : any = [];
  filterPrice: any = [];
  filterRam: any = [];
  filterBrand = [];
  filterproducts: any = [];
  isPriceCollapsed = false;
  isBrandCollapsed = false;
  isRAMCollapsed = false;
  // @Output() actions: any = new EventEmitter();

  constructor(
    private mobserv : MobileService, 
    private allapiserv : AllapiService,
    private router : Router
    ) { }

  ngOnInit(): void {
    console.log(this.product)
    this.mobserv.setSession('thisPage', 'false')
    this.mobserv.setSession('isedit', 'false')
    // this.filterproducts = this.products
    this.getProducts(this.product);
  }

  getProducts(name){
    this.allapiserv.getProd(name).subscribe(res=>{
      console.log(res);
      this.products = res;
      this.filterproducts = res;
    })
  }

  check(e, type, ev) {
    console.log(
      `${type}-->${e},event---->${ev.currentTarget.checked},type--->${type}`
    );
    let isChecked = ev.currentTarget.checked;
    if ((type == 'brand')) {
      if (isChecked) {
        this.filterBrand.push(e);
      } 
      else {
        this.filterBrand.forEach((value,index) => {
          if(value == e){
            this.filterBrand.splice(index,1);
          }
        })
      }
    } 
    else if ((type == 'price')) {
      if (isChecked) {
        this.filterPrice.push(e);
      } 
      else {
        this.filterPrice.forEach((value,index) => {
          if(value == e){
            this.filterPrice.splice(index,1);
          }
        })
      }
    } 
    else if ((type == 'ram')) {
      if (isChecked) {
        this.filterRam.push(e);
      } 
      else {
        this.filterRam.forEach((value,index) => {
          if(value == e){
            this.filterRam.splice(index,1);
          }
        })
      }
    }
    // console.log("filter Brand Array-->",this.filterBrand)
      this.filterproducts = this.filterCheckbox();
  }
  // filterbrand(){
  
  // }
  prodSearch(e,s){
    console.log(`Event---->`,e)
    console.log("Search-->",s.value)
    this.filterproducts = this.transform(this.products,s.value)
  }
  transform(items: any[], searchText: string): any[] {
    if (!items) {
      return [];
    }
    if (!searchText) {
      return items;
    }
    searchText = searchText.toLowerCase();
  
    return items.filter(it => {
      return it.brand.toLowerCase().includes(searchText);
    });
  }
  filterCheckbox() : any[]{
    let filterDup = []
    if(this.filterBrand.length != 0){
      for(let i = 0;i < this.filterBrand.length; i++){
        let it = this.filterBrand[i].toLowerCase();
        this.products.forEach(val => {
          if(it == val.brand.toLowerCase()){
            filterDup.push(val)
          }
        })
      }
    }
    // else if(this.filterBrand.length == 0){
    //   filterDup = this.products
    // }
    if(this.filterPrice.length != 0){
      // let filterDup1 = filterDup
      for(let i = 0;i < this.filterPrice.length; i++){
        let it = {
          firstVal : +this.filterPrice[i].split("-",2)[0],
          secondVal : +this.filterPrice[i].split("-",2)[1]
        }
        // this.filterPrice[i];
        console.log("range-->",it)
        this.products.forEach(val => {
          if(it.firstVal <= val.ram.price && it.secondVal >= val.ram.price){
            filterDup.push(val)
          }
        })
      }
    }
    // else if(this.filterBrand.length == 0 && this.filterPrice.length == 0){
    //   filterDup = this.products
    // }
    if(this.filterRam.length != 0){
      // filterDup = []
      for(let i = 0;i < this.filterRam.length; i++){
        let it = this.filterRam[i];
        this.products.forEach(val => {
          if(it == val.ram.size){
            filterDup.push(val)
          }
        })
      }
    }
    else if(this.filterBrand.length == 0 && this.filterPrice.length == 0 && this.filterRam.length == 0){
      filterDup = this.products
    }
    return filterDup
  }
  // details(event){
  //   let action = { 
  //     action:'details',
  //     event: event
  // };
  //   // this.actions.emit(action);
  // }
  // edit(event){
  //   let action = { 
  //     action:'edit',
  //     event: event
  // };
  //   // this.actions.emit(action);
  // }
  // delete(event){
  //   let action = { 
  //     action:'delete',
  //     event: event
  // };
  //   // this.actions.emit(action);
  // }

  details(pro){
    // this.prodServ.id = pro.id;
    this.mobserv.setSession('mobId',pro.id)
    this.router.navigateByUrl(`/detail/${pro.brand}`);
  }

  edit(mob){
    this.mobserv.setSession('isedit',true)
    this.mobserv.mobile = mob;
    this.router.navigateByUrl('/mobiles/Add')
  }
  delete(mob){
    mob.brand = mob.brand.toUpperCase();
    if(confirm(`Would you like to delete ${mob.brand} ${mob.model}?`)){
      this.mobserv.deleteMobile(mob.id).subscribe(res=>{
        this.router.navigateByUrl('/mobiles')
      })
    }
    else{
      this.router.navigateByUrl('/mobiles')
    }
  }

}
