import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { AllapiService } from 'src/app/services/allapi.service';
import { MustMatch } from 'src/app/_helpers/must-match.validator';


@Component({
  selector: 'app-joinin',
  templateUrl: './joinin.component.html',
  styleUrls: ['./joinin.component.css']
})
export class JoininComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
 
  constructor(  private formBuilder: FormBuilder,private router: Router,private myservice: AllapiService,) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastName: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      location: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9 ]*$')]],
      emailid:['',[Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6), Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{5,}')]],
      confirmpassword: ['', Validators.required],
    }, {
      validator: MustMatch('password', 'confirmpassword')
       }); 
  }
  get f() { return this.registerForm.controls; }

  openDialog(){
    Swal.fire
    ({
      title: "Registration is done!",
      text: "continue insearch of products",
      icon: "success"
    }).then((result)=> {
      if(result) {
        this.router.navigate(['/login']);
      }
    })
    
}
 
  onSubmit() {
    this.submitted = true;
 

    // stop here if form is invalid
   
    // display form values on success
    console.log(this.registerForm.value);
    let data=this.registerForm.value;
    let input = {
      "firstName":data.firstName,
      "lastName":data.lastName,
      "location":data.location,
      "emailid":data.emailid,
      "password":data.password,
    }
    this.myservice.insertData(input).subscribe(res=>{
      console.log("Insert: ", res);
      this.openDialog();
    })
    if (this.registerForm.invalid) {
      return false;
    }

    
  }

}
