import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';

import { JoininComponent } from './joinin.component';

describe('JoininComponent', () => {
  let component: JoininComponent;
  let fixture: ComponentFixture<JoininComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JoininComponent ],
      imports : [ReactiveFormsModule,RouterTestingModule,HttpClientModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JoininComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be able to Register', () => {
    component.onSubmit();
    expect(component.submitted).toBe(true);
  });
});
