import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';

import { AddMobileComponent } from './add-mobile.component';

describe('AddMobileComponent', () => {
  let component: AddMobileComponent;
  let fixture: ComponentFixture<AddMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddMobileComponent ],
      imports : [ReactiveFormsModule,
        RouterTestingModule,
        HttpClientModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should have a form to add and update Mobiles', () => {
    fixture.detectChanges();
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('[action="add"]')).toBeTruthy();
  });

  it('should be able to add mobile', () => {
    component.isupdate = "true"
    component.onSubmit();
    expect(component.submitted).toBe(true);
  });
});
