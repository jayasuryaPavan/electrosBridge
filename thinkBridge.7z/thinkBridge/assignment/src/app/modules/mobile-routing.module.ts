import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddMobileComponent } from './add-mobile/add-mobile.component';
import { MobileDetailComponent } from './mobile-detail/mobile-detail.component';
import { MobileTableComponent } from './mobile-table/mobile-table.component';

const childroutes: Routes = [
    {
        path : '' , children:[
            { path : '' , component : MobileTableComponent  },
            { path : 'detail/:id', component : MobileDetailComponent},
            { path : 'Add', component : AddMobileComponent}
        ]
    }
];
    
    @NgModule({
      imports: [RouterModule.forChild(childroutes)],
      exports: [RouterModule]
    })
    export class MobilesRoutingModule { }