import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ProdTableComponent } from '../shared/prod-table/prod-table.component';
import { SharedModule } from '../shared/shared.module';
import { AddMobileComponent } from './add-mobile/add-mobile.component';
import { MobileDetailComponent } from './mobile-detail/mobile-detail.component';
import { MobilesRoutingModule } from './mobile-routing.module';
import { MobileTableComponent } from './mobile-table/mobile-table.component';

@NgModule({
  declarations: [
    MobileTableComponent,
    MobileDetailComponent,
    AddMobileComponent
  ],
  imports: [
    CommonModule, 
    MobilesRoutingModule,
    ReactiveFormsModule,
    SharedModule
  ],
  entryComponents:[
    ProdTableComponent
  ],
})
export class MobileModule {}
