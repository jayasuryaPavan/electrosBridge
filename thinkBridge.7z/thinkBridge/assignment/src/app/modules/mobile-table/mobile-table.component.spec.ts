import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { MobileTableComponent } from './mobile-table.component';

describe('MobileTableComponent', () => {
  let component: MobileTableComponent;
  let fixture: ComponentFixture<MobileTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MobileTableComponent ],
      imports : [HttpClientModule,RouterTestingModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MobileTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should have a search to find mobile', () => {
    fixture.detectChanges();
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('[action="search"]')).toBeTruthy();
  });

  it('should have filter of mobiles and its specs', () => {
    fixture.detectChanges();
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('[action="filter"]')).toBeTruthy();
  });

  it('should have the mobiles in the lobby', () => {
    component.getAllMobiles();
    expect(component.getMobiles).toBe(true);
  });
});
