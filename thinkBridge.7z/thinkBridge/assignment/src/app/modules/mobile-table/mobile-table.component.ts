import { Router } from '@angular/router';
import { MobileService } from './../../services/mobile.service';
import { AfterViewChecked, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile-table',
  templateUrl: './mobile-table.component.html',
  styleUrls: ['./mobile-table.component.css'],
})
export class MobileTableComponent implements OnInit, AfterViewChecked {
  signedIn = false;
  isBrandCollapsed = false;
  isRAMCollapsed = false; 
  isPriceCollapsed = false;
  isbrandchecked = false;
  brands = ['Samsung', 'Apple', 'Nokia', 'OnePlus', 'OPPO', 'VIVO', 'Xiaomi'];
  prices = [
    '0-4999',
    '5000-9999',
    '10000-19999',
    '20000-29999',
    '30000-49999',
    '50000-999999',
  ];
  rams = ['1', '2', '4', '6', '8', '12', '16'];
  products :any = [];

  constructor( private mobserv: MobileService,
    private router : Router) {}

  ngOnInit(): void {
    // this.getAllMobiles();
    this.mobserv.setSession('thisPage', 'false')
    this.mobserv.setSession('isedit', 'false')
    // this.filterproducts = this.products
    this.mobserv.mobile = {
      id : null,
      brand: '',
      model:'',
      ram :{
        size : null,
        price : null,
      },
      img_URL : ''
     }
  }

  childaction(event){
    console.log(event);
  }

  ngAfterViewChecked(){
    // this.getAllMobiles();
  }

  // getAllMobiles(){
  //   this.mobserv.getMobiles().subscribe(
  //     res=>{
  //       this.products = res;
  //       // this.filterproducts = this.products
  //     }
  //   )
  // }
  details(pro){
    // this.prodServ.id = pro.id;
    this.mobserv.setSession('mobId',pro.id)
    this.router.navigateByUrl(`/detail/${pro.brand}`);
  }

  edit(mob){
    this.mobserv.setSession('isedit',true)
    this.mobserv.mobile = mob;
    this.router.navigateByUrl('/mobiles/Add')
  }
  delete(mob){
    mob.brand = mob.brand.toUpperCase();
    if(confirm(`Would you like to delete ${mob.brand} ${mob.model}?`)){
      this.mobserv.deleteMobile(mob.id).subscribe(res=>{
        this.router.navigateByUrl('/mobiles')
      })
    }
    else{
      this.router.navigateByUrl('/mobiles')
    }
  }
}