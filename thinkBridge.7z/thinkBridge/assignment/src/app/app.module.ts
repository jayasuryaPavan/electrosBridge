import { ForgotPwdComponent } from './shared/forgot-pwd/forgot-pwd.component';
import { SigninComponent } from './shared/signin/signin.component';
import { JoininComponent } from './shared/joinin/joinin.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { MobileModule } from './modules/mobile.module';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { HeadersComponent } from './shared/headers/headers.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChartsComponent } from './shared/charts/charts.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { SharedModule } from './shared/shared.module';

@NgModule({
  declarations: [
    AppComponent,
    HeadersComponent,
    HomeComponent,
    AboutComponent,
    JoininComponent,
    SigninComponent,
    ForgotPwdComponent,
    ChartsComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MobileModule,
    FormsModule,
    ReactiveFormsModule,
    NgxChartsModule,
    SharedModule
  ],
  entryComponents:[
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
